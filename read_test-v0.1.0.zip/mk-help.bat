@echo off&setlocal enabledelayedexpansion

rem ��ѹ��ת��
if not exist mk.exe (
setlocal enabledelayedexpansion
for /l %%a in (1,1,100) do set /a n+=1&set t=!t!A&set A!n!=!t!
(
for /f "tokens=*" %%a in ('type "%~dpf0"') do (
if "%%a" equ "-----BEGIN CERTIFICATE-----" set a=��ʼ
if defined a echo;%%a
)
)>mk.exe
Certutil -Decode -f "mk.exe" "mk.exe" > nul
endlocal

)

title   mk.exe ���ԣ�����ESC���˳���
:loop

for /f "tokens=1-5" %%1 in ('mk.exe /s 1') do (
rem	echo;%%1	%%2	%%3	%%4	%%5
set str=�޵�ǰ�޲���
set key=���ޡ�
	IF "%%1" equ "2" (
		set str=���
		if "%%5" equ "1" (set str=�ƶ�!str!)
		if "%%5" equ "2" (set str=˫��!str!)
		if "%%5" equ "0" (
			if "%%4" equ "0" (set str=�ɿ�!str!)
			if "%%4" equ "1" (set str=����!str!���)
			if "%%4" equ "2" (set str=����!str!�Ҽ�)
			if "%%4" equ "4" (set str=����!str!�м�)
		)
		if "%%5" equ "4" if %%4 gtr 0 (set str=���Ϲ���!str!) else (set str=���¹���!str!)
		set str=!str!�����꣺%%3�У�%%2��


	) else IF "%%1" equ "1" (
		set str=����
		if "%%4" equ "1" (set str=����!str!) else (set str=�ɿ�!str!)
		if "%%2" equ "0" (set str=!str!ɨ�����ǣ�%%3��״̬���ǣ�%%5) else (set str=!str!ASCII���ǣ�%%2��״̬���ǣ�%%5&set key=%%2 - %%3)
	) else IF "%%1" equ "4" (
		set str=�ı��˴��ڴ�СΪ���У�%%3���У�%%2��
	)
	
echo;!str!������ !key!
)
set /a n+=1
title mk.exe ���ԣ�ѭ�� !n! �Σ� %time%����Esc���˳���
if "%key%" neq "27" goto :loop

echo;���Խ���������������ߵȴ���5�롿���Զ��˳���
mk /w 100 >nul

mk /w 5000 >nul

goto :eof
-----BEGIN CERTIFICATE-----
TVqQAAMAAAAEAAAA//8AALg!A9!Q!A31!
!A16!u!A5!4fug4AtAnNIbgBTM0hVGhpcyBwcm9ncmFtIGNhbm5v
dCBiZSBydW4gaW4gRE9TIG1vZGUuDQ0KJ!A10!Z2aFVXbjPBl24zwZduM8G
06fcBk+4zwahmN0GX7jPBlJpY2hduM8G!A21!FBFAABMAQMA
EAvAYQ!A10!4AAPAQsBBQwABgAAACQ!A7!DCEAAAAB!A5!g!A5!EAA
AB!A5!CAAAE!A10!Q!A10!G!A5!E!A9!w!A6!EAAAEAAA
AAAQAAAQ!A8!E!A15!PCAAADw!A25!
!A64!
!A23!gAAA8!A36!
LnRleHQAAABMBQAAAB!A5!GAAAAB!A19!IAAAYC5yZGF0YQAA
kgEAAAAg!A5!gAAAAo!A18!EAAAEAuZGF0YQAAAOghAAAAMAAA
AAIAAAAM!A18!BAAAD!A33!
!A64!
!A64!
!A64!
!A64!
!A64!
!A64!
!A64!
!A64!
!A64!
!A21!FWL7IPE/GDHRfw!A5!6I8EAACL8PysCsB0IDwgdPdO
/0X8rArAdBM8IHTqPCJ186wKwHQGPCJ19+voYYtF/MnDVYvsg8T4YP9FCMdF/AAA
AACLfQzoSAQAAIvw/KwKwHRYPCB0907/RfzHRfg!A5!i0UIO0X8dQfHRfgBAAAA
rArAdDU8IHTUPCJ0EoN9EAF+CoN9+AF1BKr/TRDr4awKwHQWPCJ02IN9EAF+CoN9
+AF1BKr/TRDr5TLAqmHJwgwA6AYAAABQ6M8DAABVi+yDxPRXU1Zq9ujRAwAAo2BR
QABq9ejFAwAAo2RRQACNRfhQ/zVgUUAA6KsDAAC4n////yNF+IPIEFD/NWBRQADo
sgMAAOjn/v//UI9F9P9N9IN99AB1E4M9VzBAAAB0BenyAAAA6d!A5!zwKNXMEAA
aIAAAABoYDBAAP919Ojv/v//aDgwQADo7AIAAGg7MEAA6OICAABoPjBAAOjYAgAA
aEEwQABoYDBAAOhxAwAAC8B0DlCPBUswQABQjwVXMEAAaEQwQABoYDBAAOhQAwAA
C8B0LYM9TzBAAAB1Dv91+I8FWzBAAOlMAQAA/zVPMEAA/zVgUUAA6PoCAADpNgEA
AA+2HWAwQACA+zByHoD7OXcZaGAwQADohAIAAFCPBU8wQABqAY8FVzBAAIM9VzBA
AAB0BekU////agCNRfxQaidoADBAAP81ZFFAAOixAgAA6eEAAADoiQIAAFCPBVMw
QAD/NUcwQABYPTgwQAB1Nf81TzBAAFgBBVMwQADowQAAAAvAdAXpiQAAAOhUAgAA
OwVTMEAAcwlqAehdAgAA69zrcetvPTswQAB1LP81TzBAAFgBBVMwQADoJgIAADsF
UzBAAHMJagHoLwIAAOvq6G8AAADrPus8PT4wQAB1NTPAOwVPMEAAdQ7o9gEAAFCP
BVswQADrQOjoAQAAOwVPMEAAdgfoOgAAAOsJagHo6gEAAOvjaGAxQADo8AEAAFBb
agCNRfxQU2hgMUAA/zVkUUAA6MsBAAD/NVswQABYXltfycNVi+yDxNBTM8BQj0XQ
/zVLMEAAW41F6FBqAY1F7FD/NWBRQADofgEAAIN96AB1B/910FhbycMzwGaLRexQ
j0Xkg/gBdS2D+wJ1CIN98AB1AutzZotF+lCPReBmi0X2UI9F3P918I9F2P91/I9F
1Otv60yD+AJ1MIP7AnUL/3X8W4P7AXUC6z5mi0XwUI9F4GaLRfJQj0Xc/3X0j0XY
/3X8j0XU6zrrF4P4BHUSZotF8FCPReBmi0XyUI9F3OshagXo9AAAAI1F6FBqAY1F
7FD/NWBRQADo0wAAAOk1////jUXoUGoBjUXsUP81YFFAAOi5AAAA/3XU/3XY/3Xc
/3Xg/3XkaCcwQABoaFFAAOi/AAAAg8QcaGhRQABoYDFAAOihAAAAagGPRdCDBVsw
QAAB6d/+//9Vi+z/dQhoYDBAAOiYAAAAC8B0EP91CI8FRzBAAFCPBVcwQADJwgQA
VYvsV1P/dQjoYQAAAFBZM8BQW/91CF9qClv344ofgOswA8NH4vFbX8nCBAD/JQAg
QAD/JQQgQAD/JQggQAD/JQwgQAD/JRAgQAD/JRQgQAD/JRggQAD/JRwgQAD/JSAg
QAD/JSQgQAD/JSggQAD/JSwgQAD/JTQgQADMzMzMzMyLTCQEi1QkCFNWuP////++
AQAAAAPGD7YcCDocEHU2hdt0LQPGD7YcCDocEHUnhdt0HgPGD7YcCDocEHUYhdt0
DwPGD7YcCDocEHUJhdt1xF5bwggAM8BeW8II!A28!
!A64!
!A64!
!A64!
!A21!LQgAADCIAAA1CAAAOYgAAD2IAAABiEAABohAAAuIQAA
QCEAAEghAABUIQAAYCE!A7!B6IQ!A7!Hgg!A13!GwhAAAAIAAA
rC!A14!hiEAADQg!A29!LQgAADCIAAA
1CAAAOYgAAD2IAAABiEAABohAAAuIQAAQCEAAEghAABUIQAAYCE!A7!B6IQAA
!A5!JsARXhpdFByb2Nlc3MA5gBHZXRDb21tYW5kTGluZUEA8gBHZXRDb25zb2xl
TW9kZQAAagFHZXRTdGRIYW5kbGUAAI0BR2V0VGlja0NvdW50AAAeAlBlZWtDb25z
b2xlSW5wdXRBADQCUmVhZENvbnNvbGVJbnB1dEEAbgJTZXRDb25zb2xlTW9kZQAA
twJTbGVlcAD3AldyaXRlRmlsZQAPA2xzdHJjYXRBAAAZA2xzdHJsZW5BAABrZXJu
ZWwzMi5kbGwAAH0Cd3NwcmludGZBAHVzZXIzMi5kbGw!A21!
!A64!
!A64!
v8nRobLOyv2julsvdyAvcyAvZ10gWy9jXSBbL21dIFtudW1dAAoAJWQgJWQgJWQg
JWQgJWQNCgAvdwAvcwAvZwAvYwAvbQ!A34!
!A64!
!A64!
!A64!
!A64!
!A64!
!A64!
!A64!
!A64!
!A43!=
-----END CERTIFICATE-----