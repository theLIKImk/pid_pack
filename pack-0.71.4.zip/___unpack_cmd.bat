if /i "%1"=="/int" goto :int
if /i "%1"=="/aft" goto :aft
exit /b

:int
call log.cmd %PACK% INFO [%PACK%]%VERSION%#SP##SP#INSTALL#SP#NOW
exit /b

:aft
call "%PIDMD_ROOT%\___packcfg_cmd.bat"
copy "%PIDMD_ROOT%\___packcfg_cmd.bat" "%PIDMD_SYS%\PACK\PACK\packcfg_cmd.bat"
call log.cmd %PACK% INFO [%PACK%]%VERSION%#SP##SP#INSTALL#SP#OK
exit /b