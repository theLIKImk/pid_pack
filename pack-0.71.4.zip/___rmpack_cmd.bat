if /i "%1"=="/int" goto :int
if /i "%1"=="/aft" goto :aft
exit /b

:int
call log.cmd %PACK% INFO [%PACK%]%VERSION%#SP##SP#REMOVE#SP#NOW
exit /b

:aft
call log.cmd %PACK% INFO [%PACK%]%VERSION%#SP##SP#REMOVE#SP#OK
exit /b