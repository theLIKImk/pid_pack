if /i "%1"=="/rl" (
	call LOG %PACK% INFO [%PACK%]#SP#RELOADCFG
	exit /b
)

call LOG %PACK% INFO [%PACK%]#SP#SETCFG
call LOG %PACK% INFO [%PACK%]#SP#UPDATE#SP#FILES......

pushd %cd%
cd /d "%PIDMD_SYS%\PACK\"

for /d %%i in (*) do (
	if exist ".\%%i\DEPEND" (
		cd /d ".\%%i"
		ren "DEPEND" "BDEPEND"
		cd /d ".\.."
	)
)
	
popd
exit /b