@echo off
title Login

:loop
set passwd=
set Login_user=
set Login_passwd=

set /p Login_user=Login:
set /p Login_passwd=Passwd:

if not exist "%PIDMD_ALLUSER%%Login_user%" echo Login fail & goto loop
call loadcfg "%PIDMD_ALLUSER%%Login_user%"
if not "%passwd%"=="%Login_passwd%"  echo Login fail & goto loop
call :login
exit /b 0

:login
set PIDMD_USER=%Login_user%
set passwd=
set Login_user=
set Login_passwd=
cmd
exit /b 0