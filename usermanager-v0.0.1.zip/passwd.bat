@echo off
if "%pidmd_user%"=="" (
	call LOG.cmd passwd ERRO Can#sp#find#sp#user
	exit /b 1
)

set passwd_USER=%1
if not "%1"=="" goto :now_user
set passwd_USER=%PIDMD_USER%

:now_user
if not exist "%PIDMD_ALLUSER%%passwd_USER%" (
	call LOG.cmd passwd ERRO ERROR#sp#user:#sp#%passwd_USER%
	exit /b 1
)

call loadcfg %PIDMD_ALLUSER%%passwd_USER%
if not defined passwd (
	call :new_passwd
) else (
	call :re_passwd
)

set passwd=
set passwd_0=
set passwd_1=
set passwd_2=

if "%errorlevel%"=="0" (
	echo OK!
	exit /b 0
) else (
	echo FAIL!
	exit /b 1
)


:new_passwd
	set /p passwd_1=New passwd:
	set /p passwd_2=Confirm password:
	if not "%passwd_1%"=="%passwd_2%" (
		call LOGHE.cmd passwd ERRO %passwd_USER%#sp#set#sp#passwd#sp#fail
		exit /b 1
	)
	call LOGHE.cmd passwd INFO %passwd_USER%#sp#set#sp#passwd
	echo.passwd=%passwd_1%>>"%PIDMD_ALLUSER%%passwd_USER%"
exit /b

:re_passwd
	set passwd_old=%passwd%

	set /p passwd_0=Old passwd:
	if not "%passwd_0%"=="%passwd_old%" (
		call LOGHE.cmd passwd ERRO %passwd_USER%#sp#old#sp#is#sp#error
		exit /b 1
	)

	set /p passwd_1=New passwd:
	set /p passwd_2=Confirm password:
	if not "%passwd_1%"=="%passwd_2%" (
		call LOGHE.cmd passwd ERRO %passwd_USER%#sp#set#sp#passwd#sp#fail
		exit /b 1
	)
	call LOGHE.cmd passwd INFO %passwd_USER%#sp#set#sp#passwd
	call config "%PIDMD_ALLUSER%%passwd_USER%" #NONE/passwd %passwd_1%
exit /b